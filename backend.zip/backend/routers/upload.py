"""
upload.py  (updated — AI fallback integrated)
─────────────────────────────────────────────
Changes from original:
  • After graph_db.fetch_codes_from_graph(), if any entities have no Neo4j code,
    the AI fallback is triggered automatically.
  • AI suggestions are saved as PendingCodeReview rows (status="pending").
  • The upload response now includes an "ai_suggestions" key and a
    "has_pending_reviews" flag so the frontend can show the review banner.
  • Everything else (extraction → normalization → graph → rules) is unchanged.
"""

import logging
import json
import uuid
from typing import Optional

from fastapi import APIRouter, File, UploadFile, HTTPException, Depends, Form
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError, jwt
from sqlalchemy.orm import Session

from backend.database import get_db, Report
from backend.utils.auth import SECRET_KEY, ALGORITHM
from .extractionlayer import MedicalReportExtractor
from .normalizationlayer import MedicalNormalizer
from .graphlayer import MedicalKnowledgeGraph
from .ruleengine import ClinicalRuleEngine
from .ai_coding_fallback import get_ai_code_suggestions   # ← NEW 

logger = logging.getLogger(__name__)
router = APIRouter()

extractor   = MedicalReportExtractor()
normalizer  = MedicalNormalizer()
graph_db    = MedicalKnowledgeGraph()
rule_engine = ClinicalRuleEngine()

ALLOWED_EXTENSIONS = {".pdf", ".docx", ".doc", ".txt"}
ALWAYS_ALLOWED_CONTENT_TYPES = {
    "application/pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/msword",
    "text/plain",
}
GENERIC_CONTENT_TYPES = {
    "application/octet-stream",
    "application/binary",
    "",
}

security = HTTPBearer(auto_error=False)

def get_current_user_id_optional(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
) -> Optional[str]:
    if not credentials:
        return None
    token = credentials.credentials
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload.get("user_id")
    except JWTError:
        return None


from pydantic import BaseModel

class FlagReportRequest(BaseModel):
    reason: str


def generate_clinical_summary(normalized_data: dict) -> str:
    symptoms    = normalized_data.get("symptoms", [])
    diagnoses   = normalized_data.get("diagnosis", [])
    medications = normalized_data.get("medications", [])
    procedures  = normalized_data.get("procedures", [])

    parts = []
    if diagnoses:
        parts.append(f"Patient assessed and diagnosed with {', '.join(diagnoses)}.")
    else:
        parts.append("Patient assessed for clinical evaluation.")
    if symptoms:
        parts.append(f"Presenting symptoms include {', '.join(symptoms)}.")
    if medications:
        parts.append(f"Current pharmacotherapy plan consists of {', '.join(medications)}.")
    if procedures:
        parts.append(f"Diagnostic or therapeutic procedures scheduled/completed: {', '.join(procedures)}.")
    if not parts:
        return (
            "Clinical report uploaded. Evaluation completed with no significant "
            "diagnoses or symptoms extracted."
        )
    return " ".join(parts)


def _validate_file_type(filename: str, content_type: str) -> None:
    clean_name = (filename or "").split("?")[0].strip().lower()
    ext = ""
    if "." in clean_name:
        candidate = clean_name.rsplit(".", 1)[-1]
        if candidate:
            ext = "." + candidate
    ct = (content_type or "").lower().split(";")[0].strip()
    logger.info(f"File validation → filename='{filename}' ext='{ext}' content_type='{ct}'")
    if ext in ALLOWED_EXTENSIONS:
        return
    if ct in ALWAYS_ALLOWED_CONTENT_TYPES:
        return
    raise HTTPException(
        status_code=400,
        detail=(
            f"Unsupported file type. "
            f"Received extension='{ext}', content_type='{ct}'. "
            "Accepted formats: PDF (.pdf), Word (.docx / .doc), plain text (.txt)."
        ),
    )


# ─── Upload ───────────────────────────────────────────────────────────────────

@router.post("/reports/upload")
@router.post("/upload")
async def upload_medical_report(
    file: UploadFile = File(...),
    report_type: str = Form("auto"),
    db: Session = Depends(get_db),
    user_id: Optional[str] = Depends(get_current_user_id_optional),
):
    safe_filename     = (file.filename     or "unknown").strip()
    safe_content_type = (file.content_type or "").strip()

    _validate_file_type(safe_filename, safe_content_type)

    content = await file.read()

    # ── 1. Extract ────────────────────────────────────────────────────────────
    extracted_data = extractor.process_document(
        file_bytes=content,
        filename=safe_filename,
        content_type=safe_content_type,
    )

    raw_text = ""
    try:
        raw_text = extractor._extract_text(content, safe_content_type, safe_filename)
    except Exception as e:
        logger.warning(f"Could not capture raw text separately: {e}")

    # ── 2. Normalize ──────────────────────────────────────────────────────────
    normalized_data = normalizer.normalize(extracted_data)

    # ── 3. Build patient graph ────────────────────────────────────────────────
    patient_id    = user_id or "PATIENT_12345"
    graph_summary = graph_db.build_patient_graph(patient_id, normalized_data)

    # ── 4. Fetch codes from graph ─────────────────────────────────────────────
    graph_codes = graph_db.fetch_codes_from_graph(normalized_data)

    # ── 5. Apply rules ────────────────────────────────────────────────────────
    rule_results = rule_engine.apply_rules(normalized_data, graph_codes)

    # ── 6. Persist to PostgreSQL (need report_id before AI call) ─────────────
    report_id = str(uuid.uuid4())
    db_report = Report(
        id                 = report_id,
        user_id            = user_id,
        filename           = safe_filename,
        report_type        = report_type if report_type != "auto" else "Auto-detect",
        content_type       = safe_content_type or None,
        raw_text           = raw_text,
        extracted_data     = json.dumps(extracted_data),
        normalized_data    = json.dumps(normalized_data),
        graph_summary      = json.dumps(graph_summary),
        rule_engine_results= json.dumps(rule_results),
        is_flagged         = False,
    )
    db.add(db_report)
    db.commit()
    db.refresh(db_report)

    # ── 7. AI fallback for missing codes ──────────────────────────────────────
    not_found = graph_codes.get("not_found", {"diagnoses": [], "procedures": []})
    has_missing = bool(not_found.get("diagnoses") or not_found.get("procedures"))

    ai_suggestions: dict = {"icd_suggestions": [], "cpt_suggestions": [], "pending_review_ids": []}

    if has_missing:
        logger.info(
            f"Triggering AI fallback for report {report_id} — "
            f"missing: {not_found}"
        )
        ai_suggestions = get_ai_code_suggestions(
            not_found = not_found,
            raw_text  = raw_text,
            report_id = report_id,
            db        = db,
        )

    return {
        "report_id":           report_id,
        "id":                  report_id,
        "filename":            safe_filename,
        "report_type":         report_type,
        "content_type":        safe_content_type,
        "size":                len(content),
        "has_pending_reviews": has_missing,          # ← frontend shows review banner
        "message":             (
            "Report processed. Some codes require human review."
            if has_missing else
            "Diagnosis report processed and saved to database successfully."
        ),
        "data": {
            "raw_extraction":      extracted_data,
            "normalized_data":     normalized_data,
            "graph_summary":       graph_summary,
            "rule_engine_results": rule_results,
            "ai_suggestions":      ai_suggestions,   # ← pending review items
        },
    }


# ─── Results ──────────────────────────────────────────────────────────────────

@router.get("/reports/{report_id}/results")
async def get_report_results(report_id: str, db: Session = Depends(get_db)):
    db_report = db.query(Report).filter(Report.id == report_id).first()
    if not db_report:
        raise HTTPException(status_code=404, detail="Report not found")

    extracted_data  = json.loads(db_report.extracted_data       or "{}")
    normalized_data = json.loads(db_report.normalized_data      or "{}")
    rule_results    = json.loads(db_report.rule_engine_results   or "{}")

    icd_codes = rule_results.get("icd_codes", [])
    cpt_codes = rule_results.get("cpt_codes", [])

    icd10_list = []
    cpt_list   = []

    for item in icd_codes:
        diag = item.get("diagnosis")
        code = item.get("code")
        conf = extracted_data.get("confidence_scores", {}).get(diag, 0.0)
        icd10_list.append({"code": code, "description": diag, "confidence": int(conf)})

    for item in cpt_codes:
        proc = item.get("procedure")
        code = item.get("code")
        conf = extracted_data.get("confidence_scores", {}).get(proc, 0.0)
        cpt_list.append({"code": code, "description": proc, "confidence": int(conf)})

    flags = []
    for alert in rule_results.get("clinical_alerts", []):
        flags.append(alert.get("message"))
    for flag_item in rule_results.get("insurance_flags", []):
        flags.append(flag_item.get("message"))

    summary_text = generate_clinical_summary(normalized_data)
    analysed_at  = "Today, " + db_report.created_at.strftime("%I:%M %p")

    return {
        "filename":    db_report.filename,
        "report_type": db_report.report_type,
        "analysed_at": analysed_at,
        "summary":     summary_text,
        "icd10":       icd10_list,
        "cpt":         cpt_list,
        "flags":       flags,
    }


# ─── Flag ─────────────────────────────────────────────────────────────────────

@router.post("/reports/{report_id}/flag")
async def flag_report_for_review(
    report_id: str,
    body: FlagReportRequest,
    db: Session = Depends(get_db),
):
    db_report = db.query(Report).filter(Report.id == report_id).first()
    if not db_report:
        raise HTTPException(status_code=404, detail="Report not found")

    db_report.is_flagged  = True
    db_report.flag_reason = body.reason
    db.commit()

    return {
        "status":  "success",
        "message": f"Report successfully flagged for review. Reason: {body.reason}",
    }