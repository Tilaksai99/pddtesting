import logging
import json
import uuid
from typing import Optional
from fastapi import APIRouter, File, UploadFile, HTTPException, Depends, Form
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError, jwt
from sqlalchemy.orm import Session

from backend.database import get_db, Report
from backend.utils.auth import SECRET_KEY, ALGORITHM
from .extractionlayer import MedicalReportExtractor
from .normalizationlayer import MedicalNormalizer
from .graphlayer import MedicalKnowledgeGraph
from .ruleengine import ClinicalRuleEngine

logger = logging.getLogger(__name__)
router = APIRouter()

# Initialize the clinical pipeline layers once at startup
extractor   = MedicalReportExtractor()
normalizer  = MedicalNormalizer()
graph_db    = MedicalKnowledgeGraph()
rule_engine = ClinicalRuleEngine()

# ---------------------------------------------------------------------------
# Allowed types — checked by EXTENSION only (most reliable signal from Expo).
# MIME type is used as a secondary hint but never the sole gatekeeper because
# Expo/React-Native frequently sends 'application/octet-stream' regardless of
# the real file format, which was causing the 400.
# ---------------------------------------------------------------------------
ALLOWED_EXTENSIONS = {".pdf", ".docx", ".doc", ".txt"}

# MIME types that are always acceptable even without a recognised extension
ALWAYS_ALLOWED_CONTENT_TYPES = {
    "application/pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/msword",
    "text/plain",
}

# These generic types are accepted only when the file extension is also valid
GENERIC_CONTENT_TYPES = {
    "application/octet-stream",
    "application/binary",
    "",   # missing / None
}

# Optional auth — local dev sandboxes can run without login tokens
security = HTTPBearer(auto_error=False)

def get_current_user_id_optional(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
) -> Optional[str]:
    if not credentials:
        return None
    token = credentials.credentials
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload.get("user_id")
    except JWTError:
        return None


# ─── Pydantic Models ─────────────────────────────────────────────────────────

from pydantic import BaseModel

class FlagReportRequest(BaseModel):
    reason: str


# ─── Clinical Summary Generator ──────────────────────────────────────────────

def generate_clinical_summary(normalized_data: dict) -> str:
    symptoms    = normalized_data.get("symptoms", [])
    diagnoses   = normalized_data.get("diagnosis", [])
    medications = normalized_data.get("medications", [])
    procedures  = normalized_data.get("procedures", [])

    parts = []
    if diagnoses:
        parts.append(f"Patient assessed and diagnosed with {', '.join(diagnoses)}.")
    else:
        parts.append("Patient assessed for clinical evaluation.")

    if symptoms:
        parts.append(f"Presenting symptoms include {', '.join(symptoms)}.")
    if medications:
        parts.append(f"Current pharmacotherapy plan consists of {', '.join(medications)}.")
    if procedures:
        parts.append(
            f"Diagnostic or therapeutic procedures scheduled/completed: {', '.join(procedures)}."
        )

    if not parts:
        return (
            "Clinical report uploaded. Evaluation completed with no significant "
            "diagnoses or symptoms extracted."
        )
    return " ".join(parts)


# ─── Helper: validate & log file type ────────────────────────────────────────

def _validate_file_type(filename: str, content_type: str) -> None:
    """
    Raises HTTP 400 if the file is not an accepted document type.

    Rules (in priority order):
      1. Extract extension from filename (lowercased, strips query strings).
      2. If extension is in ALLOWED_EXTENSIONS → PASS (most reliable signal).
         React Native / Expo frequently sends application/octet-stream or omits
         the MIME type entirely regardless of the real file format, so extension
         is the primary and most reliable gate.
      3. Else if content_type is in ALWAYS_ALLOWED_CONTENT_TYPES → PASS.
      4. Otherwise → REJECT with a detailed message for easier debugging.
    """
    # Normalise filename: strip query params / whitespace, lowercase
    clean_name = (filename or "").split("?")[0].strip().lower()

    # Bug fix: only extract extension when a dot is present AND the dot is not
    # the very last character (e.g. "file." has no real extension).
    ext = ""
    if "." in clean_name:
        candidate = clean_name.rsplit(".", 1)[-1]   # everything after the last dot
        if candidate:                                 # non-empty → valid extension
            ext = "." + candidate

    # Normalise MIME type: lower-case, strip charset suffix (e.g. "text/plain; charset=utf-8")
    # Guard against None explicitly — FastAPI sets content_type=None when the
    # multipart part has no Content-Type header, which React Native does on Android.
    ct = (content_type or "").lower().split(";")[0].strip()

    logger.info(
        f"File validation → filename='{filename}' ext='{ext}' content_type='{ct}'"
    )

    # ── Primary gate: file extension (most reliable from mobile clients) ──────
    if ext in ALLOWED_EXTENSIONS:
        return

    # ── Secondary gate: explicit recognised MIME type ─────────────────────────
    if ct in ALWAYS_ALLOWED_CONTENT_TYPES:
        return

    # ── Both checks failed ────────────────────────────────────────────────────
    raise HTTPException(
        status_code=400,
        detail=(
            f"Unsupported file type. "
            f"Received extension='{ext}', content_type='{ct}'. "
            "Accepted formats: PDF (.pdf), Word (.docx / .doc), plain text (.txt)."
        ),
    )


# ─── API Routes ──────────────────────────────────────────────────────────────

@router.post("/reports/upload")
@router.post("/upload")
async def upload_medical_report(
    file: UploadFile = File(...),
    report_type: str = Form("auto"),
    db: Session = Depends(get_db),
    user_id: Optional[str] = Depends(get_current_user_id_optional),
):
    """
    Upload a medical report (PDF, DOCX, DOC, TXT).
    Runs the document through extraction → normalization → graph mapping → rule validation.
    Stores raw text and all layer outputs in PostgreSQL.
    """
    # Normalise potentially-None values that come from React Native / Expo clients
    # before ANY other code touches them.
    safe_filename     = (file.filename     or "unknown").strip()
    safe_content_type = (file.content_type or "").strip()

    _validate_file_type(safe_filename, safe_content_type)

    content = await file.read()

    # ── 1. Extract text & run clinical pipeline ───────────────────────────────
    extracted_data = extractor.process_document(
        file_bytes=content,
        filename=safe_filename,
        content_type=safe_content_type,
    )

    raw_text = ""
    try:
        raw_text = extractor._extract_text(
            content, safe_content_type, safe_filename
        )
    except Exception as e:
        logger.warning(f"Could not capture raw text separately: {e}")

    # ── 2. Normalize ──────────────────────────────────────────────────────────
    normalized_data = normalizer.normalize(extracted_data)

    # ── 3. Build patient knowledge graph in Neo4j ─────────────────────────────
    patient_id    = user_id or "PATIENT_12345"
    graph_summary = graph_db.build_patient_graph(patient_id, normalized_data)

    # ── 4. Fetch ICD / CPT codes from graph ontologies ────────────────────────
    graph_codes = graph_db.fetch_codes_from_graph(normalized_data)

    # ── 5. Apply pre-auth & contraindication rules ────────────────────────────
    rule_results = rule_engine.apply_rules(normalized_data, graph_codes)

    # ── 6. Persist to PostgreSQL ──────────────────────────────────────────────
    report_id = str(uuid.uuid4())
    db_report = Report(
        id=report_id,
        user_id=user_id,
        filename=safe_filename,
        report_type=report_type if report_type != "auto" else "Auto-detect",
        content_type=safe_content_type or None,
        raw_text=raw_text,
        extracted_data=json.dumps(extracted_data),
        normalized_data=json.dumps(normalized_data),
        graph_summary=json.dumps(graph_summary),
        rule_engine_results=json.dumps(rule_results),
        is_flagged=False,
    )

    db.add(db_report)
    db.commit()
    db.refresh(db_report)

    return {
        "report_id":    report_id,
        "id":           report_id,
        "filename":     safe_filename,
        "report_type":  report_type,
        "content_type": safe_content_type,
        "size":         len(content),
        "message":      "Diagnosis report processed and saved to database successfully.",
        "data": {
            "raw_extraction":      extracted_data,
            "normalized_data":     normalized_data,
            "graph_summary":       graph_summary,
            "rule_engine_results": rule_results,
        },
    }


@router.get("/reports/{report_id}/results")
async def get_report_results(report_id: str, db: Session = Depends(get_db)):
    """
    Returns medical billing and clinical evaluation results for a given report ID.
    """
    db_report = db.query(Report).filter(Report.id == report_id).first()
    if not db_report:
        raise HTTPException(status_code=404, detail="Report not found")

    extracted_data  = json.loads(db_report.extracted_data      or "{}")
    normalized_data = json.loads(db_report.normalized_data     or "{}")
    rule_results    = json.loads(db_report.rule_engine_results  or "{}")

    icd_codes = rule_results.get("icd_codes", [])
    cpt_codes = rule_results.get("cpt_codes", [])

    icd10_list = []
    cpt_list   = []

    # ICD-10 — only codes actually found in Neo4j
    for item in icd_codes:
        diag = item.get("diagnosis")
        code = item.get("code")
        conf = extracted_data.get("confidence_scores", {}).get(diag, 0.0)
        icd10_list.append({"code": code, "description": diag, "confidence": int(conf)})

    # CPT — only codes actually found in Neo4j
    for item in cpt_codes:
        proc = item.get("procedure")
        code = item.get("code")
        conf = extracted_data.get("confidence_scores", {}).get(proc, 0.0)
        cpt_list.append({"code": code, "description": proc, "confidence": int(conf)})

    # Flags — only real alerts from the rule engine
    flags = []
    for alert in rule_results.get("clinical_alerts", []):
        flags.append(alert.get("message"))
    for flag_item in rule_results.get("insurance_flags", []):
        flags.append(flag_item.get("message"))

    summary_text = generate_clinical_summary(normalized_data)
    analysed_at  = "Today, " + db_report.created_at.strftime("%I:%M %p")

    return {
        "filename":    db_report.filename,
        "report_type": db_report.report_type,
        "analysed_at": analysed_at,
        "summary":     summary_text,
        "icd10":       icd10_list,
        "cpt":         cpt_list,
        "flags":       flags,
    }


@router.post("/reports/{report_id}/flag")
async def flag_report_for_review(
    report_id: str,
    body: FlagReportRequest,
    db: Session = Depends(get_db),
):
    """Flags a processed report for manual coding review."""
    db_report = db.query(Report).filter(Report.id == report_id).first()
    if not db_report:
        raise HTTPException(status_code=404, detail="Report not found")

    db_report.is_flagged  = True
    db_report.flag_reason = body.reason
    db.commit()

    return {
        "status":  "success",
        "message": f"Report successfully flagged for review. Reason: {body.reason}",
    }